import { test, expect } from './fixtures/auth';

test('seed', async ({ loggedInPage }) => {

  expect(loggedInPage.url()).toContain('/host/#/');

  // this test uses custom fixtures from ./fixtures
});
