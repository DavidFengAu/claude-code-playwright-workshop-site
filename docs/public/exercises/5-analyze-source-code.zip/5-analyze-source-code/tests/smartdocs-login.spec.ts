import { test, expect } from './fixtures/auth';

test('verify successful login to SmartDocs 360', async ({ loggedInPage }) => {
  // Verify that the logged-in page URL contains "/host/#/"
  expect(loggedInPage.url()).toContain('/host/#/');

  // Additional verification: check for the page title
  await expect(loggedInPage).toHaveTitle(/SmartDocs 360/);
});
