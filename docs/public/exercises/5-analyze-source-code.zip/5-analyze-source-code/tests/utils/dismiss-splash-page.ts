/**
 * Splash Page Dismiss Utility
 *
 * Provides function to dismiss the splash page if present.
 */

import type { Page } from '@playwright/test'

/**
 * Dismisses the splash page if it appears
 * @param page - Playwright page object
 */
export async function dismissSplashPage(page: Page): Promise<void> {
  const dismissButton = page.getByTestId('close-splash-page-button')

  try {
    await dismissButton.waitFor({ state: 'visible', timeout: 5000 })
    await dismissButton.click()
    // eslint-disable-next-line playwright/no-wait-for-timeout
    await page.waitForTimeout(500)
    console.log('Splash page dismissed')
  } catch {
    console.log('No splash page to dismiss')
  }
}
