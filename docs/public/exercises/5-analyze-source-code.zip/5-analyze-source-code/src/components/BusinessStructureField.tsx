import { Autocomplete, TextField } from '@mui/material'
import type { Entity } from 'host/compiled-types/models'
import { BusinessStructure, BusinessStructureNameMapper } from 'host/Models'
import { values } from 'lodash'
import React from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { Controller } from 'react-hook-form'

type BusinessStructureFieldProps = Readonly<{
  formProps: UseFormReturn<Entity>
}>

const BusinessStructureField: React.FC<BusinessStructureFieldProps> = ({ formProps }) => {
  return (
    <Controller
      name='businessStructure'
      control={formProps.control}
      rules={{ required: 'Business Structure is required' }}
      render={({ field: { ref, value, ...field }, fieldState: { error } }) => {
        return (
          <Autocomplete
            {...field}
            value={value ?? null}
            autoHighlight
            fullWidth
            renderInput={(params): React.ReactElement => <TextField
              {...params}
              inputRef={ref}
              required
              label='Business Structure'
              error={Boolean(error)}
              helperText={error?.message}
              slotProps={{ inputLabel: { shrink: true } }}
            />
            }
            options={values(BusinessStructure)}
            getOptionLabel={(option): string => BusinessStructureNameMapper[option]}
            onChange={(_, selectedOption) => field.onChange(selectedOption)}
            disabled={formProps.formState.disabled}
          />
        )
      }}
    />
  )
}

export default BusinessStructureField
