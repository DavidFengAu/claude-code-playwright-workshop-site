import { Autocomplete, TextField } from '@mui/material'
import type { Entity } from 'host/compiled-types/models'
import { Industry, IndustryNameMapper } from 'host/Models'
import { values } from 'lodash'
import React from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { Controller } from 'react-hook-form'

type IndustryFieldProps = Readonly<{
  formProps: UseFormReturn<Entity>
}>

const IndustryField: React.FC<IndustryFieldProps> = ({ formProps }) => {
  return (
    <Controller
      name='industry'
      control={formProps.control}
      rules={{ required: 'Industry is required' }}
      render={({ field: { ref, value, ...field }, fieldState: { error } }) => {
        return (
          <Autocomplete
            {...field}
            value={value ?? null}
            autoHighlight
            fullWidth
            renderInput={(params): React.ReactElement => {
              return (
                <TextField
                  {...params}
                  inputRef={ref}
                  required
                  label='Industry'
                  error={Boolean(error)}
                  helperText={error?.message}
                  slotProps={{ inputLabel: { shrink: true } }}
                />
              )
            }}
            options={values(Industry)}
            getOptionLabel={(option): string => IndustryNameMapper[option]}
            onChange={(_, selectedOption) => field.onChange(selectedOption)}
            disabled={formProps.formState.disabled}
          />
        )
      }}
    />
  )
}

export default IndustryField
