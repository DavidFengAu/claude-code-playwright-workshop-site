import { Autocomplete, InputAdornment, ListItemIcon, ListItemText, MenuItem, TextField } from '@mui/material'
import { values } from 'lodash'
import React from 'react'
import type { ControllerProps } from 'react-hook-form'
import { Controller } from 'react-hook-form'

import { AustralianCurrency, currencies } from '../../../data/currencies'

type CurrencyFieldProps = Omit<ControllerProps, 'render' | 'name'>

const CurrencyField: React.FC<CurrencyFieldProps> = ({
  control,
  defaultValue,
  rules
}) => {
  return (
    <Controller
      name='currency'
      control={control}
      defaultValue={defaultValue ?? AustralianCurrency}
      rules={rules}
      render={({ field: { ref, value, onChange, ...field }, fieldState: { error }, formState: { disabled } }) => {
        return (
          <Autocomplete
            {...field}
            value={value ?? null}
            autoHighlight
            fullWidth
            renderInput={(params): React.ReactElement => {
              return (
                <TextField
                  {...params}
                  inputRef={ref}
                  required={Boolean(rules?.required)}
                  label='Currency'
                  error={Boolean(error)}
                  helperText={error?.message}
                  slotProps={{
                    inputLabel: { shrink: true },
                    input: {
                      ...params.InputProps,
                      startAdornment: value?.symbol ? <InputAdornment position='start' sx={{ ml: 0.5 }}>
                        {value.symbol}
                      </InputAdornment> : null
                    }
                  }}
                />
              )
            }}
            options={values(currencies)}
            getOptionLabel={(option): string => option.name}
            isOptionEqualToValue={(option, value) => option.code === value.code}
            renderOption={({ key, ...optionProps }, option) => {
              return (
                <MenuItem key={key} sx={{ whiteSpace: 'normal' }} {...optionProps}>
                  <ListItemIcon>{option.symbol}</ListItemIcon>
                  <ListItemText primary={option.name} />
                </MenuItem>
              )
            }}
            onChange={(_, selectedOption) => onChange(selectedOption)}
            disabled={disabled}
          />
        )
      }}
    />
  )
}

export default CurrencyField
