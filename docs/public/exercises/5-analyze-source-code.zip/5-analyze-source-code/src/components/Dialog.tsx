import { faXmark } from '@fortawesome/pro-light-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import type { DialogProps as MUIDialogProps } from '@mui/material'
import { Dialog as MUIDialog, DialogTitle } from '@mui/material'
import { IconButton, Typography } from '@mui/material'
import Box from '@mui/material/Box'
import { styled } from '@mui/material/styles'
import React from 'react'

type DialogProps = {
  isOpen: boolean
  handleClose: () => void
  title: string
  children: React.ReactNode
  dialogProps?: Partial<MUIDialogProps>
}

const Dialog: React.FC<DialogProps> = (props) => {
  const {
    isOpen,
    handleClose,
    title,
    children,
    dialogProps
  } = props

  return (
    <StyledDialog open={isOpen} {...dialogProps}>
      <DialogTitle>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Typography
            variant='h6'
            color='primary'
            sx={{ fontWeight: 'bold' }}
          >
            {title}
          </Typography>
          <IconButton
            size='medium'
            color='error'
            onClick={handleClose}
          >
            <FontAwesomeIcon icon={faXmark} />
          </IconButton>
        </Box>
      </DialogTitle>
      {children}
    </StyledDialog>
  )
}

export default Dialog

const StyledDialog = styled(MUIDialog)(({ theme, fullScreen }) => ({
  '& .MuiDialog-paper': {
    borderRadius: fullScreen ? 0 : 10
  },
  '& .MuiDialogTitle-root + .MuiDialogContent-root': {
    paddingTop: theme.spacing(2)
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(2, 3)
  }
}))
