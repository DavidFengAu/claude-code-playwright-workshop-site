import type { TextFieldProps } from '@mui/material'
import { TextField } from '@mui/material'
import React from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { Controller } from 'react-hook-form'

export type BusinessNumberFieldValues = Readonly<{
  businessNumber?: string | null
}>

type BusinessNumberFieldProps = Readonly<{
  formProps: UseFormReturn<BusinessNumberFieldValues>
  label?: string
  helperText?: React.ReactNode
  slotProps?: TextFieldProps['slotProps']
}>

const BusinessNumberField: React.FC<BusinessNumberFieldProps> = ({
  formProps,
  label,
  helperText,
  slotProps
}) => {
  return (
    <Controller
      name='businessNumber'
      control={formProps.control}
      rules={{ maxLength: { value: 20, message: 'Maximum 20 characters' } }}
      render={({ field: { ref, value, ...field }, fieldState: { error }, formState: { disabled } }) => {
        return (
          <TextField
            {...field}
            inputRef={ref}
            value={value ?? ''}
            fullWidth
            label={label ?? 'Business Number'}
            error={Boolean(error)}
            helperText={error?.message ?? helperText}
            onPaste={(event) => {
              event.preventDefault()
              field.onChange(event.clipboardData.getData('text').replace(/\s+/g, ''))
            }}
            disabled={disabled}
            slotProps={{
              ...slotProps,
              inputLabel: { shrink: true }
            }}
          />
        )
      }}
    />
  )
}

export default BusinessNumberField
