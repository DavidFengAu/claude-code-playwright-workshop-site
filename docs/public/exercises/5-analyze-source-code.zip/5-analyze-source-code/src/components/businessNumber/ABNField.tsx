import { Box, InputAdornment } from '@mui/material'
import React, { useEffect, useState } from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { useDebounce } from 'usehooks-ts'

import type { ABNDTO } from '../../../../@types/ABNDTO'
import { ABNStatus } from '../../../../models/ABN'
import WebService from '../../../../services/WebService'
import type { VerificationResult } from '../VerificationBadge'
import VerificationBadge from '../VerificationBadge'
import VerificationLink from '../VerificationLink'
import type { BusinessNumberFieldValues } from './BusinessNumberField'
import BusinessNumberField from './BusinessNumberField'

type ABNFieldProps = Readonly<{
  formProps: UseFormReturn<BusinessNumberFieldValues>
  searchText?: string
}>

const ABNField: React.FC<ABNFieldProps> = ({ formProps, searchText }) => {
  const businessNumber = formProps.watch('businessNumber')
  const isValid = !businessNumber || businessNumber?.length === 11 && (/^\d{11}$/).test(businessNumber)
  const debouncedBusinessNumber = useDebounce(businessNumber, 600)
  const [abn, setABN] = useState<ABNDTO | undefined | null>()

  useEffect(() => {
    if (businessNumber && isValid) {
      setABN(null)
      WebService.getABN(businessNumber).then(setABN)
    } else {
      setABN(undefined)
    }
  }, [debouncedBusinessNumber])

  const abnVerificationResult: VerificationResult | undefined | null = abn
    ? abn.businessEntity
      ? {
        isVerified: abn.businessEntity.entityStatus.entityStatusCode === ABNStatus.Active,
        tooltip: abn.businessEntity.entityStatus.entityStatusCode,
        helperText: <VerificationLink
          url={`https://abr.business.gov.au/ABN/View?abn=${abn.businessEntity.ABN.identifierValue}`}
          label={abn?.businessEntity?.mainName
            ? `Entity name: ${abn.businessEntity.mainName.organisationName}`
            : abn?.businessEntity?.legalName
              ? `Entity name: ${abn.businessEntity.legalName.familyName}, ${abn.businessEntity.legalName.givenName}`
              : 'View entity name'
          }
        />
      }
      : undefined
    : abn
  const helperText = abnVerificationResult
    ? abnVerificationResult.helperText
    : searchText || isValid
      ? <Box sx={{ display: 'flex', gap: 0.5 }}>
        {isValid || 'Invalid ABN.'}
        <VerificationLink
          label='Search it'
          url={`https://abr.business.gov.au/Search/ResultsActive?SearchText=${searchText}`}
        />
      </Box>
      : undefined

  return (
    <BusinessNumberField
      formProps={formProps}
      helperText={helperText}
      slotProps={{
        input: {
          startAdornment: businessNumber
            ? <InputAdornment position='start'>
              <VerificationBadge result={abnVerificationResult} />
            </InputAdornment>
            : null
        }
      }}
    />
  )
}

export default ABNField
