import React from 'react'
import type { FieldValues, UseFormReturn } from 'react-hook-form'

import ABNField from './ABNField'
import type { BusinessNumberFieldValues } from './BusinessNumberField'
import BusinessNumberField from './BusinessNumberField'
import VATNumberField from './VATNumberField'

class BusinessNumberFieldFactory<T extends FieldValues = BusinessNumberFieldValues> {
  constructor(
    private readonly formProps: UseFormReturn<T>
  ) {
  }

  visitAU(searchText?: string): React.ReactElement {
    return <ABNField formProps={this.formProps as unknown as UseFormReturn<BusinessNumberFieldValues>} searchText={searchText} />
  }

  visitGB(): React.ReactElement {
    return <VATNumberField formProps={this.formProps as unknown as UseFormReturn<BusinessNumberFieldValues>} />
  }

  visitDefault(): React.ReactElement {
    return <BusinessNumberField formProps={this.formProps as unknown as UseFormReturn<BusinessNumberFieldValues>} />
  }
}

export default BusinessNumberFieldFactory
