import { InputAdornment } from '@mui/material'
import React, { useEffect, useState } from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { useDebounce } from 'usehooks-ts'

import type { VATDTO } from '../../../../@types/VATDTO'
import WebService from '../../../../services/WebService'
import type { VerificationResult } from '../VerificationBadge'
import VerificationBadge from '../VerificationBadge'
import VerificationLink from '../VerificationLink'
import type { BusinessNumberFieldValues } from './BusinessNumberField'
import BusinessNumberField from './BusinessNumberField'

type VATNumberFieldProps = Readonly<{
  formProps: UseFormReturn<BusinessNumberFieldValues>
}>

const VATNumberField: React.FC<VATNumberFieldProps> = ({ formProps }) => {
  const businessNumber = formProps.watch('businessNumber')
  const debouncedBusinessNumber = useDebounce(businessNumber, 600)
  const [vat, setVAT] = useState<VATDTO | undefined | null>()

  useEffect(() => {
    if (businessNumber) {
      setVAT(null)
      WebService.getVAT(businessNumber).then(setVAT)
    } else {
      setVAT(undefined)
    }
  }, [debouncedBusinessNumber])

  const vatVerificationResult: VerificationResult | undefined | null = vat
    ? vat.target && vat.target?.vatNumber === businessNumber
      ? {
        isVerified: true,
        tooltip: 'Verified',
        helperText: <VerificationLink
          url='https://www.tax.service.gov.uk/check-vat-number/enter-vat-details'
          label={`Business name: ${vat.target.name}`}
        />
      }
      : undefined
    : vat

  return (
    <BusinessNumberField
      formProps={formProps}
      label='VAT Number'
      helperText={vatVerificationResult?.helperText}
      slotProps={{
        input: {
          startAdornment: businessNumber
            ? <InputAdornment position='start'>
              <VerificationBadge result={vatVerificationResult} />
            </InputAdornment>
            : null
        }
      }}
    />
  )
}

export default VATNumberField
