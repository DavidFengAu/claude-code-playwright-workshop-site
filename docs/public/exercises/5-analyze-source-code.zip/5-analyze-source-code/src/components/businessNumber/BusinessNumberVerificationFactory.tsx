import { Box } from '@mui/material'
import React from 'react'

import { ABNStatus } from '../../../../models/ABN'
import WebService from '../../../../services/WebService'
import type { VerificationResult } from '../VerificationBadge'
import VerificationBadge from '../VerificationBadge'
import VerificationLink from '../VerificationLink'

class BusinessNumberVerificationFactory {
  async visitAU(abn: string): Promise<VerificationResult | undefined> {
    const dto = await WebService.getABN(abn)
    return dto && dto.businessEntity?.entityStatus.entityStatusCode === ABNStatus.Active ? {
      helperText: <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
        <VerificationBadge result={{
          isVerified: true,
          tooltip: 'Business number verified'
        }}/>
        <VerificationLink
          url={`https://abr.business.gov.au/ABN/View?abn=${dto.businessEntity?.ABN.identifierValue}`}
          label={dto.businessEntity?.mainName
            ? `Entity name: ${dto.businessEntity.mainName.organisationName}`
            : dto.businessEntity?.legalName
              ? `Entity name: ${dto.businessEntity.legalName.familyName}, ${dto.businessEntity.legalName.givenName}`
              : 'View entity name'
          }
        />
      </Box>
    } : undefined
  }

  async visitGB(vat: string): Promise<VerificationResult | undefined> {
    const dto = await WebService.getVAT(vat)
    return dto && dto.target?.vatNumber === vat ? {
      helperText: <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
        <VerificationBadge result={{
          isVerified: true,
          tooltip: 'VAT number verified'
        }}/>
        <VerificationLink
          url='https://www.tax.service.gov.uk/check-vat-number/enter-vat-details'
          label={`VAT Number: ${dto.target.vatNumber} | Business name: ${dto.target.name}`}
        />
      </Box>
    } : undefined
  }
}

export default BusinessNumberVerificationFactory
