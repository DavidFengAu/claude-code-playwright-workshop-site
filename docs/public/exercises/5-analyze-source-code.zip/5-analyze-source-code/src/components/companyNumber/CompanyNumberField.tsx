import { TextField } from '@mui/material'
import React from 'react'
import type { UseFormReturn } from 'react-hook-form'
import { Controller } from 'react-hook-form'

export type CompanyNumberFieldValues = Readonly<{
  companyNumber?: string | null
}>

type CompanyNumberFieldProps = Readonly<{
  formProps: UseFormReturn<CompanyNumberFieldValues>
  helperText?: React.ReactNode
}>

const CompanyNumberField: React.FC<CompanyNumberFieldProps> = ({ formProps, helperText }) => {
  return (
    <Controller
      name='companyNumber'
      control={formProps.control}
      rules={{ maxLength: { value: 20, message: 'Maximum 20 characters' } }}
      render={({ field: { ref, value, ...field }, fieldState: { error }, formState: { disabled } }) => {
        return (
          <TextField
            {...field}
            inputRef={ref}
            value={value ?? ''}
            fullWidth
            label='Company Number'
            error={Boolean(error)}
            helperText={error?.message ?? helperText}
            onPaste={(event) => {
              event.preventDefault()
              field.onChange(event.clipboardData.getData('text').replace(/\s+/g, ''))
            }}
            disabled={disabled}
            slotProps={{ inputLabel: { shrink: true } }}
          />
        )
      }}
    />
  )
}

export default CompanyNumberField
