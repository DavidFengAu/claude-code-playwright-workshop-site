import React from 'react'
import type { FieldValues, UseFormReturn } from 'react-hook-form'

import ACNField from './ACNField'
import type { CompanyNumberFieldValues } from './CompanyNumberField'
import CompanyNumberField from './CompanyNumberField'

class CompanyNumberFieldFactory<T extends FieldValues = CompanyNumberFieldValues> {
  constructor(
    private readonly formProps: UseFormReturn<T>
  ) {
  }

  visitAU(searchText?: string): React.ReactElement {
    return <ACNField
      formProps={this.formProps as unknown as UseFormReturn<CompanyNumberFieldValues>} searchText={searchText}
    />
  }

  visitDefault(): React.ReactElement {
    return <CompanyNumberField formProps={this.formProps as unknown as UseFormReturn<CompanyNumberFieldValues>} />
  }
}

export default CompanyNumberFieldFactory
