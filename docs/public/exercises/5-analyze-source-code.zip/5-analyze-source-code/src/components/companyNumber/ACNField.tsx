import React from 'react'
import type { UseFormReturn } from 'react-hook-form'

import ACNVerificationLink from './ACNVerificationLink'
import type { CompanyNumberFieldValues } from './CompanyNumberField'
import CompanyNumberField from './CompanyNumberField'

type ACNFieldProps = Readonly<{
  formProps: UseFormReturn<CompanyNumberFieldValues>
  searchText?: string
}>

const ACNField: React.FC<ACNFieldProps> = ({ formProps, searchText }) => {
  const companyNumber = formProps.watch('companyNumber')

  return (
    <CompanyNumberField
      formProps={formProps}
      helperText={<ACNVerificationLink
        searchText={searchText}
        acn={companyNumber ?? undefined}
        isVerified={companyNumber?.length === 9}
      />}
    />
  )
}

export default ACNField
