import React from 'react'

import VerificationLink from '../VerificationLink'

type ACNVerificationLinkProps = Readonly<{
  searchText?: string
  acn?: string
  isVerified?: boolean
}>

const ACNVerificationLink: React.FC<ACNVerificationLinkProps> = ({ searchText, acn, isVerified }) => {
  if (!searchText && !acn) return null

  if (acn && isVerified) {
    return <VerificationLink
      label='View it'
      url={`https://abr.business.gov.au/Search/ResultsActive?SearchText=${acn}`}
    />
  }

  if (searchText) {
    return <VerificationLink
      label='Search it'
      url={`https://abr.business.gov.au/Search/ResultsActive?SearchText=${searchText}`}
    />
  }

  return null
}

export default ACNVerificationLink
