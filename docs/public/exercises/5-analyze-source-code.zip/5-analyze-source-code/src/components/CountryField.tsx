import { Autocomplete, Box, InputAdornment, lighten, ListItemIcon, ListItemText, MenuItem, TextField } from '@mui/material'
import { values } from 'lodash'
import React from 'react'
import type { ControllerProps } from 'react-hook-form'
import { Controller } from 'react-hook-form'

import { AustraliaCountry, countries } from '../../../data'
import type { Country } from '../../../data/countries'

export const CountryFlag: React.FC<{ countryCode: string }> = ({ countryCode }) => {
  return <img
    loading='lazy'
    width='20'
    srcSet={`https://flagcdn.com/w40/${countryCode}.png 2x`}
    src={`https://flagcdn.com/w20/${countryCode}.png`}
    alt=''
    style={{ border: '1px solid #E6E6E6' }}
  />
}

type CountryFieldProps = Omit<ControllerProps, 'render'> & Readonly<{
  updateCurrency?: (currencyCode: string) => void
}>

const CountryField: React.FC<CountryFieldProps> = ({
  name,
  control,
  defaultValue,
  rules,
  updateCurrency
}) => {
  return (
    <Controller
      name={name}
      control={control}
      defaultValue={defaultValue ?? AustraliaCountry}
      rules={rules}
      render={({ field: { ref, value, onChange, ...field }, fieldState: { error }, formState: { disabled } }) => {
        return (
          <Autocomplete
            {...field}
            value={value ?? null}
            autoHighlight
            fullWidth
            renderInput={(params): React.ReactElement => {
              return (
                <TextField
                  {...params}
                  inputRef={ref}
                  required={Boolean(rules?.required)}
                  label='Country'
                  error={Boolean(error)}
                  helperText={error?.message}
                  slotProps={{
                    inputLabel: { shrink: true },
                    input: {
                      ...params.InputProps,
                      startAdornment: value?.code ? <InputAdornment position='start' sx={{ ml: 0.5 }}>
                        <CountryFlag countryCode={value.code.toLowerCase()} />
                      </InputAdornment> : null
                    }
                  }}
                />
              )
            }}
            options={values(countries)}
            getOptionLabel={(option): string => option.name}
            isOptionEqualToValue={(option, value) => option.code === value.code}
            renderOption={({ key, ...optionProps }, option) => {
              return (
                <MenuItem key={key} sx={{ whiteSpace: 'normal' }} {...optionProps}>
                  <ListItemIcon><CountryFlag countryCode={option.code.toLowerCase()} /></ListItemIcon>
                  <ListItemText primary={option.name} />
                </MenuItem>
              )
            }}
            groupBy={({ isPopular }) => isPopular ? 'Popular' : 'Other Countries'}
            renderGroup={(params) => {
              return (
                <Box key={params.key}>
                  <Box sx={(theme) => ({
                    p: 1,
                    backgroundColor: lighten(theme.palette.semiLight.light, 0.6),
                    color: theme.palette.gray.main })}
                  >
                    {params.group}
                  </Box>
                  {params.children}
                </Box>
              )
            }}
            onChange={(_, selectedOption: Country | null) => {
              onChange(selectedOption)
              if (selectedOption && updateCurrency) {
                updateCurrency(selectedOption.currency_code)
              }
            }}
            disabled={disabled}
          />
        )
      }}
    />
  )
}

export default CountryField
