import type { ButtonProps } from '@mui/material'
import { Button } from '@mui/material'
import React, { forwardRef, useMemo, useState } from 'react'

type LoadingButtonProps = ButtonProps & {
  children?: React.ReactNode
  onClick: (() => Promise<unknown>) | (() => void)
  onSuccess?: () => void
  onError?: () => void
  hideTextBelowLg?: boolean
}

export const LoadingButton = forwardRef<HTMLButtonElement, LoadingButtonProps>(({
  children,
  onClick,
  disabled,
  loading,
  onSuccess,
  onError,
  hideTextBelowLg,
  ...others
}, ref) => {
  const [isSuccess, setIsSuccess] = useState<boolean | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const shouldApply = useMemo(() => isSuccess !== null, [isSuccess])

  const handleOnClick = (): Promise<void> | void => {
    if (isSuccess == null) {
      setIsLoading(true)
      return onClick()
        ?.then(() => {
          setIsSuccess(true)
          onSuccess?.()
        })
        .catch(() => {
          setIsSuccess(false)
          onError?.()
        })
        .finally(() => {
          setIsLoading(false)
          setTimeout(() => setIsSuccess(null), 1800)
        }) || setIsLoading(false)
    } else {
      return Promise.resolve()
    }
  }

  return (
    <Button
      ref={ref}
      {...others}
      variant={others.variant ?? 'contained'}
      onClick={(e) => {
        e.stopPropagation()
        handleOnClick()
      }}
      color={shouldApply
        ? isSuccess
          ? 'success'
          : 'error'
        : others.color
      }
      startIcon={shouldApply
        ? isSuccess
          ? <i className='fa-light fa-circle-check' style={{ fontSize: '13px' }} />
          : <i className='fa-light fa-circle-exclamation' style={{ fontSize: '13px' }} />
        : others.startIcon
      }
      disabled={isSuccess !== null ? true : disabled}
      loading={loading ?? isLoading}
      sx={{
        minWidth: hideTextBelowLg ? 'auto' : 90,
        '&.Mui-disabled:not(.MuiLoadingButton-loading)': (theme) => ({
          color: shouldApply ? 'white' : undefined,
          fontWeight: 500,
          backgroundColor: shouldApply
            ? isSuccess
              ? theme.palette.success.main
              : theme.palette.error.main
            : undefined,
          cursor: 'not-allowed'
        }),
        '& .MuiButton-startIcon': { marginRight: hideTextBelowLg ? 0 : undefined },
        ...others.sx
      }}
    >
      {hideTextBelowLg
        ? ''
        : shouldApply ? isSuccess ? 'Done' : 'Error' : children
      }
    </Button>
  )
})

export default LoadingButton
