import { faExclamation } from '@fortawesome/duotone-light-svg-icons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { Autocomplete, Box, TextField, Tooltip } from '@mui/material'
import { styled } from '@mui/material/styles'
import React, { useEffect, useState } from 'react'

import type { EntityManagementGroupDTO } from '../../../@types/EntityManagementDTO'
import useCRUD from '../../../hooks/useCRUD'

type ManagementGroupFieldProps = Readonly<{
  selectedEntityManagementGroups: EntityManagementGroupDTO[] | undefined
  handleSelectEntityManagementGroups: (entityManagementGroups: EntityManagementGroupDTO[]) => void
}>

const ManagementGroupField: React.FC<ManagementGroupFieldProps> = ({
  selectedEntityManagementGroups,
  handleSelectEntityManagementGroups
}) => {
  const [entityManagementGroups, setEntityManagementGroups] = useState<EntityManagementGroupDTO[] | undefined>()
  const { handleFetchEMGroups } = useCRUD()

  useEffect(() => {
    handleFetchEMGroups().then(setEntityManagementGroups)
  }, [])

  return (
    <Autocomplete
      multiple
      autoHighlight
      fullWidth
      options={entityManagementGroups ?? []}
      getOptionLabel={(option): string => option.name}
      filterSelectedOptions
      renderInput={(params): React.ReactElement => {
        return (
          <TextField
            {...params}
            label={<Box sx={{ display: 'inline-flex', alignItems: 'center' }}>
            Assign to User-Entity Groups
              <Tooltip
                title='Assign entity to groups to manage user access.
              Where groups are not selected, entity is only accessible by this user and Admin users.'
                placement='top'
                arrow
              >
                <StyledIconBox>
                  <FontAwesomeIcon icon={faExclamation} rotation={180} />
                </StyledIconBox>
              </Tooltip>
            </Box>}
            placeholder='Select groups'
            slotProps={{ inputLabel: { shrink: true } }}
          />
        )
      }}
      value={selectedEntityManagementGroups ?? []}
      onChange={(_event, groups): void => handleSelectEntityManagementGroups(groups)}
      slotProps={{ listbox: { sx: { maxHeight: 300 } } }}
    />
  )
}

export default ManagementGroupField

const StyledIconBox = styled(Box)(({ theme }) => ({
  width: 14,
  height: 14,
  borderRadius: '50%',
  backgroundColor: theme.palette.gray.main,
  color: theme.palette.gray.contrastText,
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  cursor: 'pointer',
  fontSize: '9px',
  marginLeft: 5
}))
