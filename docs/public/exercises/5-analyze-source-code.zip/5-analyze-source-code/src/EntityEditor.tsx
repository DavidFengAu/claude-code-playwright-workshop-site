import { Button, DialogActions, DialogContent, Divider, Grid2 as Grid, InputAdornment, TextField, Typography } from '@mui/material'
import { size } from 'lodash'
import React, { useEffect } from 'react'
import type { Control } from 'react-hook-form'
import { useForm } from 'react-hook-form'

import BusinessStructureField from './components/BusinessStructureField'
import EntityCodeField from './components/EntityCodeField'
import IndustryField from './components/IndustryField'
import NameField from './components/NameField'
import CompanyNumberFieldFactory from "./components/companyNumber/CompanyNumberFieldFactory";
import BusinessNumberFieldFactory from "./components/businessNumber/BusinessNumberFieldFactory";
import {CountryFlag} from "./components/CountryField";
import CurrencyField from "./components/CurrencyField";
import Dialog from "./components/Dialog";
import LoadingButton from "./components/LoadingButton";
import Entity from "./models/Entity";

type EditorProps = Readonly<{
  editorTitle: string
  entity: Entity | undefined
  handleClose: () => void
  buttonTitle?: string,
  handleSubmit?: (entity: Entity) => Promise<void>
  disabled?: true
}>

const Editor: React.FC<EditorProps> = ({
  editorTitle,
  entity,
  handleClose,
  buttonTitle,
  handleSubmit,
  disabled
}) => {
  const formProps = useForm<Entity>({ mode: 'all', defaultValues: entity, disabled })

  useEffect(() => {
    if (entity) {
      formProps.reset(entity?.copy({}))
    }
  }, [entity])

  if (!entity) return null

  const formValue = formProps.watch()
  const businessNumberFieldFactory = new BusinessNumberFieldFactory<Entity>(formProps)
  const companyNumberFieldFactory = new CompanyNumberFieldFactory<Entity>(formProps)

  return (
    <Dialog
      isOpen={Boolean(entity)}
      handleClose={handleClose}
      title={editorTitle}
      dialogProps={{ maxWidth: 'lg', fullWidth: true }}
    >
      <DialogContent>
        <Grid container size={12} spacing={2}>
          <Grid size={{ xs: 12, sm: 3 }}>
            <Typography>Details</Typography>
          </Grid>
          <Grid container spacing={2} size={{ xs: 12, sm: 9 }}>
            <Grid size={12}>
              <NameField formProps={formProps} />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <BusinessStructureField formProps={formProps} />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <IndustryField formProps={formProps} />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <TextField
                label='Country'
                fullWidth
                value={entity.country?.name}
                disabled={true}
                slotProps={{
                  inputLabel: { shrink: true },
                  input: {
                    startAdornment: entity.country?.code ? <InputAdornment position='start'>
                      <CountryFlag countryCode={entity.country.code.toLowerCase()} />
                    </InputAdornment> : undefined
                  }
                }}
              />
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <CurrencyField
                control={formProps.control as unknown as Control}
                rules={{ required: 'Currency is required' }}
              />
            </Grid>
          </Grid>
          <Grid size={12}>
            <Divider sx={(theme) => ({ margin: theme.spacing(3, 0), opacity: '0.6' })} />
          </Grid>
        </Grid>
        <Grid container size={12} spacing={2}>
          <Grid size={{ xs: 12, sm: 3 }}>
            <Typography>Identification</Typography>
          </Grid>
          <Grid container spacing={2} size={{ xs: 12, sm: 9 }}>
            <Grid size={{ xs: 12, md: 4 }}>
              {formValue.country?.renderBusinessNumberField
                ? formValue.country.renderBusinessNumberField(businessNumberFieldFactory, formValue.name ?? undefined)
                : businessNumberFieldFactory.visitDefault()
              }
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              {formValue.country?.renderCompanyNumberField
                ? formValue.country?.renderCompanyNumberField(companyNumberFieldFactory, formValue.name ?? undefined)
                : companyNumberFieldFactory.visitDefault()
              }
            </Grid>
            <Grid size={{ xs: 12, md: 4 }}>
              <EntityCodeField formProps={formProps} />
            </Grid>
          </Grid>
        </Grid>
      </DialogContent>
      {disabled || !buttonTitle ||!handleSubmit
        ? null
        : <DialogActions>
          <Button
            variant='text'
            color='gray'
            onClick={handleClose}
          >
            Cancel
          </Button>
          <LoadingButton
            onClick={formProps.handleSubmit((data: Entity) => handleSubmit(data))}
            disabled={size(formProps.formState.errors) > 0}
            sx={{ minWidth: 'auto' }}
          >
            {buttonTitle}
          </LoadingButton>
        </DialogActions>
      }
    </Dialog>
  )
}
export default Editor
