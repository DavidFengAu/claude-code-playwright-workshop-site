import type { Dayjs } from 'dayjs'
import dayjs from 'dayjs'
import { includes, orderBy, split, toUpper, values } from 'lodash'

import type { EntityDTO } from '../../@types/EntityDTO'
import type { Country } from '../../data/countries'
import { countries } from '../../data/countries'
import type { Currency } from '../../data/currencies'
import { currencies } from '../../data/currencies'
import { ConnectionApp } from '../ConnectionApp'
import { Integration, Integrations } from '../Integration'
import { PagePath } from '../Page'
import type { BusinessStructure, Industry } from './EntityNameMapper'

export enum EntityStatus {
  Active = 'active',
  Disabled = 'disabled'
}

export default class Entity {
  constructor(
    readonly id = '',
    readonly name?: string | null,
    readonly smartdocsEmail?: string,
    readonly country?: Country | null,
    readonly currency?: Currency | null,
    readonly businessStructure?: BusinessStructure | null,
    readonly businessNumber?: string | null,
    readonly companyNumber?: string | null,
    readonly entityCode?: string | null,
    readonly industry?: Industry | null,
    readonly integrations?: Integrations,
    readonly isListing?: boolean,
    readonly createdBy?: string,
    readonly createdDateTime?: Dayjs,
    readonly status?: EntityStatus,
    readonly settingsId?: string,
    readonly pages?: number
  ) {
  }

  static fromJson(dto: EntityDTO, isListing: boolean): Entity {
    const integrations = dto.integrations?.map((dto) => Integration.fromJson(dto))
    const accountingApp = orderBy(integrations, 'dateCreated', 'desc')
      .find((integration) => includes(values(ConnectionApp), integration.registrationType))
    const country = dto.country ? countries.find(({ code }) => code === dto.country) : undefined
    const currency = dto.currency ? currencies.find(({ code }) => code === dto.currency) : undefined

    return new Entity(
      dto.id,
      dto.name,
      dto.smartdocsEmail,
      country,
      currency,
      dto.businessStructure,
      dto.businessNumber,
      dto.companyNumber,
      dto.entityCode,
      dto.industry,
      integrations ? new Integrations(accountingApp) : undefined,
      isListing,
      dto.createdBy,
      dto.createdDateTime ? dayjs(dto.createdDateTime) : undefined,
      dto.status,
      dto.settingsId,
      dto.pages
    )
  }

  copy({
    id = this.id,
    name = this.name,
    smartdocsEmail = this.smartdocsEmail,
    country = this.country,
    currency = this.currency,
    businessStructure = this.businessStructure,
    businessNumber = this.businessNumber,
    companyNumber = this.companyNumber,
    entityCode = this.entityCode,
    industry = this.industry,
    integrations = this.integrations,
    isListing = this.isListing,
    status = this.status,
    settingsId = this.settingsId
  }: Partial<Entity>): Entity {
    return new Entity(id, name, smartdocsEmail, country, currency, businessStructure, businessNumber, companyNumber, entityCode,
      industry, integrations, isListing, this.createdBy, this.createdDateTime, status, settingsId, this.pages)
  }

  avatarName(): string {
    const names: string[] = split(this.name, ' ', 2)
    return names.length > 1 ? toUpper(names[0][0] + names[1][0]) : toUpper(names[0].slice(0, 2))
  }

  getAccountingApp(): Integration | undefined {
    return this.integrations?.accountingApp
  }

  hasActiveAccountingApp(): boolean {
    return Boolean(this.getAccountingApp()?.isIntegrationActive())
  }

  getActiveXero(): Integration | undefined {
    return this.integrations?.getActiveXero()
  }

  getActiveQuickbooks(): Integration | undefined {
    return this.integrations?.getActiveQuickBooks()
  }

  isActive(): boolean {
    return this.status === EntityStatus.Active
  }

  withPagePath(path: string): string {
    return `${path}?entityid=${this.id}`
  }

  withDocumentPage(): string {
    return this.withPagePath(`${window.location.origin}${window.location.pathname}#${PagePath.Documents}`)
  }

  withConnectionPage(): string {
    return this.withPagePath(`${window.location.origin}${window.location.pathname}#${PagePath.Connections}`)
  }

  baseEntityDTO(): EntityDTO {
    return {
      name: this.name?.trim() ?? '',
      businessStructure: this.businessStructure as BusinessStructure,
      industry: this.industry as Industry,
      country: this.country?.code ?? null,
      currency: this.currency?.code ?? null,
      businessNumber: this.businessNumber ? this.businessNumber : null,
      companyNumber: this.companyNumber ? this.companyNumber : null,
      entityCode: this.entityCode ? this.entityCode : null
    }
  }

  toAddEntityDTO(): EntityDTO {
    return this.baseEntityDTO()
  }

  toUpdateEntityDTO(): EntityDTO {
    return this.baseEntityDTO()
  }
}
